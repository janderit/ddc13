﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace NugetTool
{
    public static class Dependencies
    {
        public static IEnumerable<NugetDependency> Find(string project)
        {
            var packages = XDocument.Load(Path.Combine(project, "packages.config")).Element("packages");
            return
                packages.Elements("package").Select(dep => new NugetDependency(dep.Attribute("id").Value, dep.Attribute("version").Value));
        }
    }

    public struct NugetDependency
    {
        public readonly string Id;
        public readonly string Version;

        public NugetDependency(string id, string version)
        {
            Id = id;
            Version = version;
        }
    }
}
